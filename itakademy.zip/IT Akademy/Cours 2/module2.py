import module1

a=2

print(module1.carre(a))
print(module1.compte_voyelles("Thibaut"))