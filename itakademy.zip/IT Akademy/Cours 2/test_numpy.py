'''
numpy permet de manipuler efficacement de grandes quantités
de données numériques
'''
import numpy as np

#l'objet de bas de numpy est l'array
#c'est un tableau qui peut avoir plusieurs dimensions
a=np.array([5,3,8,1,0])
print(a)
print("dimension :",a.ndim)
print("shape :",a.shape)
print()

array2d = np.array([ [3,2,1], [6,5,4]])
print(array2d)
print("dimension :",array2d.ndim)
print("shape :",array2d.shape)
print()

array3d = np.array([[ [5,1,0], [3,5,7], [0,8,1] ],
                    [ [2,2,3], [-1,5,4], [6,6,0]]])
print(array3d)
print("dimension :",array3d.ndim)
print("shape :",array3d.shape)
print()

#les operations se font élément par élément
print("a=",a)
print("a+2=",a+2)

def f(x):
    return x**2+3*x-8

print("f(a)=",f(a))

#création d'arrays
#arange(start,stop,step) crée un array 1D de start à stop
#avec despas de step
b=np.arange(3,14,2)
print(b)

#linspace crée un array 1d de a à b avec n points
c=np.linspace(3,8,15)
print(c)
