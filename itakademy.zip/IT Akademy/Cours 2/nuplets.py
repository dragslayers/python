#un tuple rassemble des objets de taille fixe
#utilisé pour représenter un petit nombre de données qui
#fonctionnent ensemble (qui sont indiscossiables)

couple1=(3,2)
couple2=(-1,0)

triplet1=(9,1,7)

print(couple1)
print(couple1[0])

#contrairment aux listes, on ne peut pas rajouter d'éléments
#ni modifier un seul élément