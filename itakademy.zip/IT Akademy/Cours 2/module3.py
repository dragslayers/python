from module1 import * #pour utiliser les fonctions sans préfixe

print(carre(3))
