import module1 as m1 #alias

print("__name__ du module 1 :",m1.__name__)
print("__name__ dans le module 4 :",__name__)
print(m1.carre(7))
